function helloworld() {
    console.log("안녕하세요");
}

//함수 호출시: sayhello()