const btn=document.querySelector(
    ".btn"
)