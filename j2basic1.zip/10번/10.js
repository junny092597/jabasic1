function multiplyTwo(number) {
    var result = number * 2;
    console.log(result);
}