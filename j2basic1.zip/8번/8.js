function showPrompt() {
    var userInput = prompt("원하는 내용을 입력하세요:"); 
  
        alert("사용자 입력: " + userInput); 
    }
